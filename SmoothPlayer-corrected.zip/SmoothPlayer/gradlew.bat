@echo off
setlocal
set GRADLE_VERSION=8.7
set ROOT_DIR=%~dp0
set CACHE_DIR=%USERPROFILE%\.gradle\smoothplayer-bootstrap\%GRADLE_VERSION%
set DIST_DIR=%CACHE_DIR%\gradle-%GRADLE_VERSION%
set ZIP=%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip
if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
  if not exist "%ZIP%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%CACHE_DIR%'"
)
call "%DIST_DIR%\bin\gradle.bat" --project-dir "%ROOT_DIR%" %*
endlocal
