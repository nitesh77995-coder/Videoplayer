# SmoothPlayer

A simple Android video player starter project using AndroidX Media3/ExoPlayer.

## Important build fix

This project includes an executable `gradlew` in the repository root. It bootstraps Gradle 8.7 on CI, so GitHub Actions does not fail with `chmod: cannot access 'gradlew'` when the project is uploaded from a phone.

## Build

```bash
./gradlew assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Features

- Pick a local video with the Android document picker.
- Media3/ExoPlayer playback.
- Seek/play/pause controls.
- 1x / 1.25x / 1.5x / 2x playback speed.
- Display enhancement mode using player surface scaling.

Note: true AI upscaling and frame interpolation require device/GPU-specific processing and are not implemented by this starter build.
