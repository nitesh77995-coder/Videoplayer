package com.smoothplayer.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.ComponentActivity;
import androidx.annotation.Nullable;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends ComponentActivity {
    private static final int PICK_VIDEO = 1001;
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView status;
    private float speed = 1.0f;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playerView = findViewById(R.id.player_view);
        status = findViewById(R.id.status_text);
        Button open = findViewById(R.id.open_button);
        Button speedButton = findViewById(R.id.speed_button);
        Button enhanceButton = findViewById(R.id.enhance_button);

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        playerView.setUseController(true);

        player.addListener(new Player.Listener() {
            @Override public void onIsPlayingChanged(boolean isPlaying) {
                status.setText(isPlaying ? "Playing" : "Paused");
            }
            @Override public void onPlayerError(PlaybackException error) {
                status.setText("Playback error: " + error.errorCodeName);
            }
        });

        open.setOnClickListener(v -> openVideo());
        speedButton.setOnClickListener(v -> {
            if (speed == 1.0f) speed = 1.25f;
            else if (speed == 1.25f) speed = 1.5f;
            else if (speed == 1.5f) speed = 2.0f;
            else speed = 1.0f;
            player.setPlaybackSpeed(speed);
            speedButton.setText("Speed " + speed + "x");
        });
        enhanceButton.setOnClickListener(v -> {
            // A safe display enhancement mode: use the player's highest available surface scaling.
            playerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT);
            enhanceButton.setText("Enhancement ON");
            status.setText("Enhancement mode enabled");
        });
    }

    private void openVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        startActivityForResult(intent, PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException ignored) { }
            player.setMediaItem(MediaItem.fromUri(uri));
            player.prepare();
            player.play();
            status.setText("Playing selected video");
        }
    }

    @Override protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override protected void onDestroy() {
        if (player != null) player.release();
        super.onDestroy();
    }
}
